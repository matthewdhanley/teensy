#include "IntervalTimer.h"
#include "AltEncoder.h"

namespace AltEncoder
{
    IntervalTimer Controller::timer;
    Encoder** Controller::encList;
}

